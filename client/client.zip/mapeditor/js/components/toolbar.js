export default class ToolBar {
	constructor() {
		
	}
}