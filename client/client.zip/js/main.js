import Client from './client.js';

class Main {
	constructor() {
		this.client = new Client();
	}
}

new Main();